import React from "react";
import {
  IonBackButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";

import "./About.css";

const About: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton></IonBackButton>
          </IonButtons>
          <IonTitle>Privacy police</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <div className="about__content">
          Welcome to our mobile app! We're excited to bring you a seamless
          shopping experience with our Shopify-powered platform. Our app lets
          you browse and purchase products from our store from the comfort of
          your own phone. We offer a wide selection of products that you can
          filter by category, price, and other features.
          <br />
          Our app also includes features such as a wishlist, cart, and checkout,
          so you can easily keep track of your purchases and complete your
          orders with just a few taps. Plus, our app is optimized for mobile, so
          you can shop on-the-go without any hassle.
          <br />
          We're committed to providing you with excellent customer service, so
          if you have any questions or concerns, please don't hesitate to reach
          out to us using the contact information provided in the app. Thank you
          for choosing to shop with us, and we hope you enjoy using our app!
        </div>
      </IonContent>
    </IonPage>
  );
};

export default About;
