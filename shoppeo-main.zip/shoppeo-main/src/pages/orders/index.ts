import Orders from "./Orders";

export default Orders;
