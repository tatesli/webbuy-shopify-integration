import React from "react";
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonButtons,
  IonBackButton,
  IonTitle,
  IonContent,
  IonLoading,
} from "@ionic/react";
import { TOKEN_KEY, getLocalStorage } from "utils/helper";
import useOrdersQuery from "hooks/useOrdersQuery";
import "./Orders.css";
import classNames from "classnames";

enum FinStatus {
  paid = "PAID",
  unpaid = "UNPAID",
}

const Orders: React.FC = () => {
  const token = getLocalStorage(TOKEN_KEY);
  const { data, loading } = useOrdersQuery({ token });

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton></IonBackButton>
          </IonButtons>
          <IonTitle>Orders</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen className="orders__content">
        <IonLoading isOpen={loading}></IonLoading>
        {data && !loading && (
          <div className="orders__content">
            {data.map((order) => (
              <div className="orders__order-wrap">
                <div className="orders__order-product-list">
                  {order.products.map(({ title, quantity }) => (
                    <div>
                      {title} - {quantity}
                    </div>
                  ))}
                  <div>
                    {order.amount} {order.currencyCode}
                  </div>
                </div>
                <div className="order__status-wrap">
                  <div
                    className={classNames(
                      "order__status",
                      order.financialStatus === FinStatus.paid
                        ? "order__status-paid"
                        : "order__status-unpaid"
                    )}
                  >
                    {order.financialStatus}
                  </div>
                  <a href={`${order.statusUrl}`} className="order__link">
                    check status
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </IonContent>
    </IonPage>
  );
};

export default Orders;
