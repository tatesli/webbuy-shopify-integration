import React, { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { RouteComponentProps } from "react-router-dom";
import {
  IonBackButton,
  IonBadge,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonLabel,
  IonLoading,
  IonPage,
  IonSelect,
  IonSelectOption,
  IonTitle,
  IonToast,
  IonToolbar,
} from "@ionic/react";
import { cartOutline, heart, heartOutline } from "ionicons/icons";

import "./ProductDetails.css";
import { Product as ProductType } from "feature/categories/products";
import { RatingStar } from "feature/categories";

import { selectProduct, setProductDetails } from "store/products";
import useProductQuery, { ProductVariant } from "hooks/useProductQuery";
import { colors } from "utils/colors";
import classNames from "classnames";
import Button from "components/button/Button";
import { useMutation } from "@apollo/client";
import { cartCreate, cartLineAdd } from "services/cart";
import { selectCartId, setCartId } from "store/cart";
import useCartQuery from "hooks/useCartQuery";
import useProductRecommendationsQuery, {
  Product,
} from "hooks/useProductRecommendations";
import ProductCard from "feature/categories/components/Product";
import { ProductCardType } from "pages/products/Products";
import { usePrevious } from "utils/hooks";

interface MatchParams {
  genderId: string;
  categoryId: string;
  productId: string;
}

interface VisibleProductVariant {
  title: string;
  id: string;
  availableForSale: boolean;
  image: string;
  price: { amount: string; currencyCode: string };
  size: string;
  color: string;
}

enum Options {
  color = "Color",
  size = "Size",
}

interface ProductDetailsProps extends RouteComponentProps<MatchParams> {}

const ProductDetails: React.FC<ProductDetailsProps> = ({ history, match }) => {
  const genderId = match.params.genderId;
  const categoryId = match.params.categoryId;
  const dispatch = useDispatch();
  const product = useSelector(selectProduct);
  const cartId = useSelector(selectCartId);
  const { totalQuantity, refetch } = useCartQuery({ id: cartId });
  const { data: products } = useProductRecommendationsQuery({
    id: product!.id,
  });
  const { data, loading, error } = useProductQuery({ id: product!.id });
  const [createCart, { data: cartData }] = useMutation(cartCreate);
  const [addToCart] = useMutation(cartLineAdd);
  const [visibleProduct, setVisibleProduct] =
    useState<VisibleProductVariant | null>(null);
  const [showToast, setShowToast] = useState(false);
  const [ratingValue, setRatingValue] = useState(0);
  const [favorite, setFavorite] = useState(false);
  const [selectedSize, setSelectedSize] = useState<string>("");
  const [selectedColor, setSelectedColor] = useState<string>("");
  const prevProductId = usePrevious(visibleProduct?.id);

  const onAddToCartBtnClick = async () => {
    if (!cartId) {
      await createCart({
        variables: {
          cart: {
            lines: [{ merchandiseId: visibleProduct?.id }],
          },
        },
      });
    } else {
      await addToCart({
        variables: {
          id: cartId,
          items: [{ merchandiseId: visibleProduct?.id }],
        },
      });
    }

    setShowToast(true);
  };

  useEffect(() => {
    if (!cartData || cartId) {
      return;
    }
    const { id } = cartData?.cartCreate?.cart;
    if (id) {
      console.log("has id");
      // @ts-ignore
      dispatch(setCartId({ cartId: id }));
    }
  }, [cartData]);

  const handleAddToCart = () => {
    history.push("/home/cart");
    refetch();
  };
  const onSaveRating = (index: number) => {
    setRatingValue(index);
  };
  const handleProduct = (product: Product) => {
    history.push(`/categories/${genderId}/${categoryId}/${product.handle}`);
    dispatch(setProductDetails(product));
    setVisibleProduct(null);
  };
  const handleLike = (e: any) => {
    e.stopPropagation();
    setFavorite(!favorite);
  };
  const getSelectedOptions = (variant: ProductVariant) => {
    const size =
      variant.selectedOptions.find((option) => option.name === Options.size)
        ?.value ?? "";
    const color =
      variant.selectedOptions.find((option) => option.name === Options.color)
        ?.value ?? "";

    return { size, color };
  };
  useEffect(() => {
    if (!data || visibleProduct) {
      return;
    }
    const { variants } = data;

    const { size, color } = getSelectedOptions(variants[0]);
    const { selectedOptions, ...restVariantProps } = variants[0];

    setVisibleProduct({ ...restVariantProps, size, color });
    setSelectedColor(color);
    setSelectedSize(size);
  }, [data, visibleProduct, prevProductId]);

  const productColors = useMemo(
    () => data?.options.find((option) => option.name === Options.color)?.values,
    [data]
  );
  const productSizes = useMemo(
    () => data?.options.find((option) => option.name === Options.size)?.values,
    [data]
  );
  const handleColorChange = (selectedColor: string) => {
    setSelectedColor(selectedColor);
    const variant = data?.variants.find(
      (variant) =>
        variant.selectedOptions.find((option) => option.name === Options.color)
          ?.value === selectedColor &&
        variant.selectedOptions.find((option) => option.name === Options.size)
          ?.value === selectedSize
    );
    if (!variant) {
      return;
    }
    const { size, color } = getSelectedOptions(variant);

    setVisibleProduct({ ...variant, size, color });
  };
  const handleSizeChange = (selectedSize: string) => {
    setSelectedSize(selectedSize);
    const variant = data?.variants.find(
      (variant) =>
        variant.selectedOptions.find((option) => option.name === Options.size)
          ?.value === selectedSize &&
        variant.selectedOptions.find((option) => option.name === Options.color)
          ?.value === selectedColor
    );
    if (!variant) {
      return;
    }
    const { size, color } = getSelectedOptions(variant);

    setVisibleProduct({ ...variant, size, color });
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton
              text=""
              className="header__back-btn"
              defaultHref={`/categories/${genderId}/${categoryId}`}
            ></IonBackButton>
          </IonButtons>
          <IonTitle className="header__title">Product</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonLoading isOpen={loading} duration={0}></IonLoading>
        {!loading && !error && visibleProduct && data ? (
          <div className="product-details">
            <div
              className={classNames(
                "product-details__image-wrapper",
                !visibleProduct.availableForSale &&
                  "product-details__image-wrapper-not-available"
              )}
            >
              <img src={visibleProduct.image} alt={data.title} />
              <div className="product-details__block-favorite">
                <IonIcon
                  slot="icon-only"
                  icon={favorite ? heart : heartOutline}
                  style={{ color: "red" }}
                  onClick={handleLike}
                />
              </div>
              {!visibleProduct.availableForSale && (
                <div className="product-details__not-available">
                  Not Available
                </div>
              )}
            </div>
            <div className="product-details__color">
              <div className="product-details__color-title">Colors</div>
              {productColors?.map((color, idx) => (
                <button
                  key={idx}
                  onClick={() => handleColorChange(color)}
                  className={`product-details__color-btn ${
                    color === selectedColor
                      ? `product-details__color-btn--active`
                      : ``
                  }`}
                  style={{
                    background: colors[`${color.toLowerCase()}`],
                  }}
                ></button>
              ))}
            </div>
            <div className="product-details__rating">
              <RatingStar
                value={ratingValue}
                readonly={true}
                onSaveRating={(value) => {
                  onSaveRating(value);
                }}
              />
            </div>
            <div className="product-details__description">
              <div className="product-details__description-title">
                {data.title}
              </div>
            </div>
            <div className="product-details__similar-product">
              {products?.map((product) => (
                <div
                  className="product-details__similar-product-details"
                  key={product.id}
                >
                  <ProductCard
                    product={product}
                    onClick={() => handleProduct(product)}
                    type={ProductCardType.grid}
                  />
                </div>
              ))}
            </div>
            <div className="product-details__price">
              <div className="product-details__price-left">
                <div className="product-details__price-left-category">
                  {data.productType}
                </div>
                <div className="product-details__price-left-title">
                  {data.title}
                </div>
              </div>
              <div className="product-details__price-right">
                {visibleProduct.price.amount}
                {visibleProduct.price.currencyCode}
              </div>
            </div>
            <div className="product-details__block-bottom">
              <div className="product-details__block-bottom-size-btn">
                <IonLabel>Select size</IonLabel>
                <IonSelect
                  interface="action-sheet"
                  placeholder="Select One"
                  onIonChange={(e) => handleSizeChange(e.detail.value)}
                  value={selectedSize}
                >
                  <div className="product-details__block-bottom-size-btn-popover">
                    {productSizes?.map((itemSize) => (
                      <IonSelectOption value={itemSize} key={itemSize}>
                        {itemSize}
                      </IonSelectOption>
                    ))}
                  </div>
                </IonSelect>
              </div>
              <div className="product-details__cart-button">
                <Button
                  onClick={onAddToCartBtnClick}
                  label="add"
                  disabled={!visibleProduct.availableForSale}
                >
                  <IonIcon icon={cartOutline}></IonIcon>
                </Button>
              </div>
            </div>
            <IonToast
              isOpen={showToast}
              onDidDismiss={() => setShowToast(false)}
              message="Your item has been added to your cart"
              position="top"
              duration={1000}
            />
          </div>
        ) : (
          <div>Product not found </div>
        )}
      </IonContent>
    </IonPage>
  );
};

export default ProductDetails;
