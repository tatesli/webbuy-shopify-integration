import React from "react";
import { useHistory } from "react-router";
import { IonContent, IonPage, IonList, IonLoading } from "@ionic/react";

import useCollectionsQuery, { Collection } from "hooks/useCollectionsQuery";
import "./Categories.css";
import { useDispatch } from "react-redux";
import { setCollection } from "store/products";

const Categories: React.FC = () => {
  const { loading, error, data } = useCollectionsQuery();
  const dispatch = useDispatch();
  const history = useHistory();

  const handleCollection = (collection: Collection) => {
    dispatch(setCollection(collection));
    history.push(`/categories/${collection.title}`);
  };

  return (
    <IonPage>
      <IonContent fullscreen>
        <IonLoading isOpen={loading} duration={0}></IonLoading>
        {!loading && !error && data && (
          <IonList>
            {data.map((item) => (
              <div
                className="categories_list-item"
                key={item.id}
                onClick={() => handleCollection(item)}
              >
                <div className="categories_title">
                  {item.title.toUpperCase()}
                </div>
                <div className="categories_img-wrap">
                  <img
                    src={item.image.url}
                    alt={item.id}
                    className="categories_img"
                  />
                </div>
              </div>
            ))}
          </IonList>
        )}
      </IonContent>
    </IonPage>
  );
};

export default Categories;
