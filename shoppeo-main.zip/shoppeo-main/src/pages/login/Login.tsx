import React from "react";
import { useForm } from "react-hook-form";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router";
import { useMutation } from "@apollo/client";
import {
  IonHeader,
  IonPage,
  IonToolbar,
  IonTitle,
  IonContent,
  IonLoading,
} from "@ionic/react";

import Input from "components/input/Input";
import Button from "components/button/Button";
import { login, logout } from "store/auth";
import { customerAccessTokenCreate } from "services/auth";
import "./Login.css";

const Login: React.FC = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const [creteAccessToken, { loading }] = useMutation(
    customerAccessTokenCreate
  );
  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    setValue,
  } = useForm<{ email: string; password: string }>({ mode: "all" });

  const onSubmit = handleSubmit(async (data) => {
    try {
      const result = await creteAccessToken({
        variables: { customer: { ...data } },
      });

      if ("data" in result) {
        const { accessToken } =
          result.data.customerAccessTokenCreate.customerAccessToken;
        // @ts-ignore
        dispatch(login({ token: accessToken }));
      }
    } catch (error) {
      // @ts-ignore
      dispatch(logout());
    }
  });

  const email = watch("email");
  const password = watch("password");
  const onChange = (e: any, name: string) => {
    setValue(name as "email" | "password", e.target.value);
  };
  const handleNavigateToRegister = () => {
    history.push("/register");
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Login</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonLoading isOpen={loading} duration={0}></IonLoading>
        {!loading && (
          <div className="login__wrapper">
            <div className="login__input-wrapper">
              <Input
                label="Email"
                placeholder="Enter Email"
                name="email"
                type="text"
                value={email}
                onChange={onChange}
                error={errors?.email?.message}
                ref={
                  register("email", {
                    pattern: {
                      value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                      message: "Email is not valid",
                    },
                    required: { value: true, message: "Email is required" },
                  }) as any
                }
              />
            </div>
            <div className="login__input-wrapper">
              <Input
                label="Password"
                placeholder="Enter password"
                name="password"
                type="password"
                value={password}
                onChange={onChange}
                error={errors?.password?.message}
                ref={
                  register("password", {
                    required: { value: true, message: "Password is required" },
                  }) as any
                }
              />
            </div>
            <div className="login__button-wrap">
              <Button onClick={onSubmit} label="Login" />
            </div>
            <div className="login__button-wrap">
              <Button
                onClick={handleNavigateToRegister}
                label="Register"
                fill
              />
            </div>
          </div>
        )}
      </IonContent>
    </IonPage>
  );
};

export default Login;
