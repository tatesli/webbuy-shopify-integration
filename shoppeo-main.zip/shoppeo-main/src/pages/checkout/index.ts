import Checkout from "./Checkout";

export default Checkout;
