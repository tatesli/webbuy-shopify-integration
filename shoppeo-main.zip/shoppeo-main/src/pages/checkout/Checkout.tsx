import React from "react";
import { useForm } from "react-hook-form";
import {
  IonBackButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonLoading,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import Button from "components/button/Button";
import Input from "components/input/Input";

import "./Checkout.css";
import { useMutation } from "@apollo/client";
import { checkoutCreate, updateCheckout } from "services/checkout";
import { TOKEN_KEY, getLocalStorage } from "utils/helper";
import useCustomerQuery from "hooks/useCustomerQuery";
import { useDispatch, useSelector } from "react-redux";
import { selectCartId } from "store/cart";
import useCartQuery from "hooks/useCartQuery";
import { setCheckout } from "store/checkout";
import { useHistory } from "react-router";

const Checkout: React.FC = () => {
  const dispatch = useDispatch();
  const history = useHistory();

  const [checkoutCreateRes, { loading }] = useMutation(checkoutCreate);
  const token = getLocalStorage(TOKEN_KEY);
  const { data: userData } = useCustomerQuery({ token });
  const cartId = useSelector(selectCartId);
  const { data: cartData } = useCartQuery({ id: cartId! });

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
    setValue,
  } = useForm<{
    firstName: string;
    lastName: string;
    country: string;
    city: string;
    phone: string;
    address1: string;
    address2: string;
    zip: string;
  }>({ mode: "all" });
  const onChange = (e: any, name: string) => {
    setValue(
      name as
        | "firstName"
        | "lastName"
        | "country"
        | "city"
        | "phone"
        | "address1"
        | "address2"
        | "zip",
      e.target.value
    );
  };
  const firstName = watch("firstName");
  const lastName = watch("lastName");
  const country = watch("country");
  const city = watch("city");
  const phone = watch("phone");
  const address1 = watch("address1");
  const address2 = watch("address2");
  const zip = watch("zip");
  const onSubmit = handleSubmit(async (data) => {
    try {
      const result = await checkoutCreateRes({
        variables: {
          input: {
            email: userData?.email,
            buyerIdentity: { countryCode: "PL" },
            allowPartialAddresses: false,
            shippingAddress: { ...data },

            lineItems: cartData?.items.map(({ id, quantity }) => ({
              variantId: id,
              quantity,
            })),
          },
        },
      });

      const checkout = result.data?.checkoutCreate?.checkout;
      if (checkout) {
        dispatch(setCheckout(checkout));
        history.push("/cart/checkout/order");
      }
    } catch (error) {
      console.log(error);
    }
  });

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton></IonBackButton>
          </IonButtons>
          <IonTitle>Checkout</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonLoading isOpen={loading} duration={0}></IonLoading>
        {!loading && (
          <div className="checkout__wrapper">
            <div className="checkout__input-wrapper">
              <Input
                label="First Name"
                placeholder="Enter First Name"
                name="firstName"
                type="text"
                value={firstName}
                onChange={onChange}
                error={errors?.firstName?.message}
                ref={
                  register("firstName", {
                    minLength: {
                      value: 3,
                      message: "First Name must be at least 3 characters.",
                    },
                    maxLength: {
                      value: 20,
                      message:
                        "First Name must be less than or equal to 20 characters.",
                    },
                  }) as any
                }
              />
            </div>
            <div className="checkout__input-wrapper">
              <Input
                label="Last Name"
                placeholder="Enter Last Name"
                name="lastName"
                type="text"
                value={lastName}
                onChange={onChange}
                error={errors?.lastName?.message}
                ref={
                  register("lastName", {
                    minLength: {
                      value: 3,
                      message: "Last Name must be at least 3 characters.",
                    },
                    maxLength: {
                      value: 20,
                      message:
                        "Last Name must be less than or equal to 20 characters.",
                    },
                  }) as any
                }
              />
            </div>
            <div className="checkout__input-wrapper">
              <Input
                label="Country"
                placeholder="Enter country"
                name="country"
                type="text"
                value={country}
                onChange={onChange}
                error={errors?.country?.message}
                ref={register("country") as any}
              />
            </div>
            <div className="checkout__input-wrapper">
              <Input
                label="City"
                placeholder="Enter city"
                name="city"
                type="text"
                value={city}
                onChange={onChange}
                error={errors?.city?.message}
                ref={register("city") as any}
              />
            </div>
            <div className="checkout__input-wrapper">
              <Input
                label="Phone"
                placeholder="+48"
                name="phone"
                type="text"
                value={phone}
                onChange={onChange}
                error={errors?.phone?.message}
                ref={register("phone") as any}
              />
            </div>
            <div className="checkout__input-wrapper">
              <Input
                label="Address 1"
                placeholder="Enter address 1"
                name="address1"
                type="address1"
                value={address1}
                onChange={onChange}
                error={errors?.address1?.message}
                ref={
                  register("address1", {
                    required: { value: true, message: "Address 1 is required" },
                  }) as any
                }
              />
            </div>
            <div className="checkout__input-wrapper">
              <Input
                label="Address 2"
                placeholder="Enter address 2"
                name="address2"
                type="address2"
                value={address2}
                onChange={onChange}
                error={errors?.address1?.message}
                ref={
                  register("address1", {
                    required: { value: true, message: "Address 2 is required" },
                  }) as any
                }
              />
            </div>
            <div className="checkout__input-wrapper">
              <Input
                label="Zip code"
                placeholder="Enter Zip Code"
                name="zip"
                type="zip"
                value={zip}
                onChange={onChange}
                error={errors?.zip?.message}
                ref={
                  register("zip", {
                    required: { value: true, message: "Zip code is required" },
                  }) as any
                }
              />
            </div>
            <div className="checkout__input-wrapper">
              <Button onClick={onSubmit} label="Continue" />
            </div>
          </div>
        )}
      </IonContent>
    </IonPage>
  );
};

export default Checkout;
