import React from "react";
import {
  IonBackButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonItem,
  IonLabel,
  IonList,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import "./Order.css";
import { useSelector } from "react-redux";
import { selectCheckout } from "store/checkout";
import classNames from "classnames";
import Button from "components/button/Button";
import {
  checkoutCompleteFree,
  checkoutCompleteV2,
  updateCheckout,
} from "services/checkout";
import { useMutation } from "@apollo/client";

const Order: React.FC = () => {
  const order = useSelector(selectCheckout);
  const [completeCheckout] = useMutation(checkoutCompleteFree);
  const [checkoutUpdate] = useMutation(updateCheckout);

  const handleCheckout = async () => {
    await checkoutUpdate({ variables: { id: order.id } }).then(async () => {
      await completeCheckout({
        variables: {
          checkoutId: order.id,
        },
      });
    });
  };
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton></IonBackButton>
          </IonButtons>
          <IonTitle>Order summary</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <div className="order__list-header">Products</div>
        <IonList>
          {order.items.map((product: any) => (
            <IonItem>
              <div className="order__product-wrapper">
                <div className="order__product-img-wrapper">
                  <img src={product.variant.image.url} alt={product.title} />
                </div>
                <div className="order__product-description">
                  <div className="order__product-title">
                    <div>{product.title}</div>
                    <div>{product.variant.title}</div>
                  </div>
                  <div className="order__product-price">
                    {product.quantity}
                    {" / "}
                    {product.quantity *
                      Number(product.variant.price.amount)}{" "}
                    {product.variant.price.currencyCode}
                  </div>
                </div>
              </div>
            </IonItem>
          ))}
        </IonList>
        <div className="order__list-header">Info</div>
        <div className="order__info-wrapper">
          <div className="order__info">
            <h4 className="order__info-title">Date:</h4>
            <h4 className="order__info-sub-title">{order.createdAt}</h4>
          </div>
          <div className={classNames("order__info", "order__info-mt-10")}>
            <h4 className="order__info-title">Address:</h4>
            <h4 className="order__info-sub-title">
              {order.shippingAddress.country}, {order.shippingAddress.city},{" "}
              {order.shippingAddress.address1},{order.shippingAddress.zip},{" "}
              {order.shippingAddress.phone}, {order.shippingAddress.firstName}{" "}
              {order.shippingAddress.lastName}
            </h4>
          </div>
        </div>
        <div className="order__list-header">Cost</div>
        <div className="order__amount">
          <IonList>
            <IonItem>
              <IonLabel>Subtotal:</IonLabel>
              <p>
                {order.lineItemsSubtotalPrice.amount}{" "}
                {order.lineItemsSubtotalPrice.currencyCode}
              </p>
            </IonItem>

            <IonItem>
              <IonLabel>Taxes:</IonLabel>
              <p>
                {order.totalTax.amount} {order.totalTax.currencyCode}
              </p>
            </IonItem>
            <IonItem className="order__cost-total">
              <IonLabel>Total:</IonLabel>
              <p>
                {order.totalPrice.amount} {order.totalPrice.currencyCode}
              </p>
            </IonItem>
          </IonList>
          <div>
            <Button label="Complete Checkout" onClick={handleCheckout} />
          </div>
        </div>
      </IonContent>
    </IonPage>
  );
};

export default Order;
