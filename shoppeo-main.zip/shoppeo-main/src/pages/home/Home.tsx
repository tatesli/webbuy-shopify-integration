import React from "react";
import {
  IonContent,
  IonHeader,
  IonLoading,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import "./Home.css";
import useMainProductsQuery, { Product } from "hooks/useMainProductsQuery";

import { RouteComponentProps, useHistory } from "react-router";
import { useDispatch } from "react-redux";
import { setProductDetails } from "store/products";

interface MatchParams {
  genderId: string;
  categoryId: string;
}

interface HomeProps extends RouteComponentProps<MatchParams> {}
const Home: React.FC<HomeProps> = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const { data, loading, error } = useMainProductsQuery();
  console.log(data);
  const handleNavigate = (product: Product) => {
    history.push(`/home/${product.handle}`);
    dispatch(setProductDetails(product));
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Home</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <IonLoading isOpen={loading} duration={0}></IonLoading>
        {data && !loading && (
          <div className="home__content">
            {data.map((product) => (
              <div
                className="home__content-item"
                onClick={() => handleNavigate(product)}
              >
                <img src={product.image} alt={product.title} />
                <div className="home__content-item-desc-wrap">
                  <div className="home__content-item-price">
                    {product.price.amount} {product.price.currencyCode}
                  </div>
                  <div className="home__content-item-title">
                    {product.title}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </IonContent>
    </IonPage>
  );
};
export default Home;
