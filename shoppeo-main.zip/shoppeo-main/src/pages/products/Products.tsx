import {
  IonActionSheet,
  IonBackButton,
  IonBadge,
  IonButton,
  IonButtons,
  IonCheckbox,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonItem,
  IonLabel,
  IonLoading,
  IonModal,
  IonPage,
  IonRange,
  IonRefresher,
  IonRefresherContent,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import {
  cartOutline,
  filterOutline,
  gridOutline,
  listOutline,
  optionsOutline,
  refreshOutline,
} from "ionicons/icons";

import React, { useCallback, useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import { RouteComponentProps } from "react-router";
import ProductCard from "feature/categories/components/Product";
// import { selectCartItems } from '../store/cart'
import {
  categories,
  Colors,
  fetchProducts,
  ProductCategory,
  ProductSize,
  SizeProduct,
} from "../../feature/categories/products";
import { usePrevious } from "../../utils/hooks";
import "./Products.css";
import { FilterModal } from "feature/categories";
import {
  selectCollection,
  selectProducts,
  selectProductsType,
  setProductDetails,
  setProducts,
} from "../../store/products";
import useProductsQuery, { Product } from "hooks/useProductsQuery";
import { selectCartId } from "store/cart";
import useCartQuery from "hooks/useCartQuery";

export enum ProductCardType {
  list = "list",
  grid = "grid",
}

export enum SortOption {
  priceLow = 1,
  priceHigh = 2,
}

interface MatchParams {
  genderId: string;
  categoryId: string;
}

interface ProductsProps extends RouteComponentProps<MatchParams> {}

const Products: React.FC<ProductsProps> = ({ history, match }) => {
  const genderId = match.params.genderId;
  const categoryId = match.params.categoryId;
  const collection = useSelector(selectCollection);
  const productsType = useSelector(selectProductsType);
  const [sort, setSort] = useState<SortOption>(SortOption.priceLow);

  const { loading, error, data } = useProductsQuery({
    id: collection!.id,
    type: productsType!.productType,
    sort,
  });

  const category = useRef<ProductCategory | null>(null);
  if (genderId && (!category.current || category.current.slug !== genderId)) {
    category.current = categories.find(({ slug }) => slug === genderId) || null;
  } else if (!genderId && category.current) {
    category.current = null;
  }

  const productList = useSelector(selectProducts);
  const dispatch = useDispatch();

  const [productsIsLoading, setProductsIsLoading] = useState(true);

  const [visibleProducts, setVisibleProducts] = useState<Product[]>();
  const [productPageNumber, setProductPageNumber] = useState<number | null>(
    null
  );

  const [errorMessage, setErrorMessage] = useState("");
  const loader = useRef<{ complete: () => void } | null>(null);
  const [size, setSize] = useState<SizeProduct | SizeProduct[]>();
  const [showFilterModal, setShowFilterModal] = useState(false);

  const [pageView, setPageView] = useState<ProductCardType>(
    ProductCardType.grid
  );

  const [showSortPriceActionSheet, setShowSortPriceActionSheet] =
    useState(false);

  const handleProduct = (product: Product) => {
    history.push(`/categories/${genderId}/${categoryId}/${product.handle}`);
    dispatch(setProductDetails(product));
  };

  const setSortOption = useCallback(
    (sortOption: SortOption) => {
      setSort(sortOption);
    },
    [setSort]
  );
  const doRefresh = (e: any) => {
    setProductPageNumber(null);
    loader.current = e.target;
  };
  const onInfiniteScroll = (e: any) => {
    setProductPageNumber((productPageNumber || 0) + 1);

    loader.current = e.target;
  };

  const getGoBackUrl = () => {
    if (category.current?.name) {
      return `/home/categories/${categoryId}`;
    }
    return `/home/categories/`;
  };
  const onListBtnClick = () => {
    setPageView(ProductCardType.list);
  };
  const onGridBtnClick = () => {
    setPageView(ProductCardType.grid);
  };

  const handleShowFilterModal = () => setShowFilterModal(true);
  const handleCloseFilterModal = () => setShowFilterModal(false);

  return (
    <IonPage>
      <IonHeader className="header">
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton
              text=""
              defaultHref={getGoBackUrl()}
              className="header__back-btn"
            ></IonBackButton>
          </IonButtons>
          <IonTitle className="header__title">
            {category.current?.name || "Products"}
          </IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        {showFilterModal && (
          <FilterModal
            isOpen={showFilterModal}
            onClose={handleCloseFilterModal}
            products={productList}
          />
        )}
        <IonRefresher slot="fixed" onIonRefresh={doRefresh}>
          <IonRefresherContent></IonRefresherContent>
        </IonRefresher>

        {!!error ? (
          <div className="content">
            <div className="content__error-title">
              <IonLabel>{errorMessage}</IonLabel>
            </div>
            <div className="content__error-btn">
              <IonButton onClick={() => doRefresh}>
                Retry<IonIcon slot="end" icon={refreshOutline}></IonIcon>
              </IonButton>
            </div>
          </div>
        ) : loading ? (
          <IonLoading isOpen={loading} duration={0}></IonLoading>
        ) : !data ? (
          <div className="content__error-title">No products</div>
        ) : (
          <div
            className={`${
              pageView === ProductCardType.grid
                ? "products--grid"
                : "products--list"
            }`}
          >
            {data?.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onClick={() => handleProduct(product)}
                type={pageView}
              />
            ))}
          </div>
        )}

        <IonInfiniteScroll
          disabled={
            !visibleProducts ||
            visibleProducts.length === 0 ||
            !!errorMessage ||
            productsIsLoading
          }
          onIonInfinite={onInfiniteScroll}
        >
          <IonInfiniteScrollContent
            loading-spinner="bubbles"
            loading-text="Loading more data..."
          ></IonInfiniteScrollContent>
        </IonInfiniteScroll>
      </IonContent>
      <IonFooter className="products-footer">
        <IonToolbar>
          <IonButtons slot="start">
            <IonButton fill="clear" color="dark" onClick={onListBtnClick}>
              <IonIcon slot="icon-only" icon={listOutline}></IonIcon>
            </IonButton>
            <IonButton fill="clear" color="dark" onClick={onGridBtnClick}>
              <IonIcon slot="icon-only" icon={gridOutline}></IonIcon>
            </IonButton>
          </IonButtons>
          <IonTitle>{visibleProducts?.length} Products</IonTitle>
          <IonButtons slot="end">
            <IonButton
              color="dark"
              fill="clear"
              onClick={setShowSortPriceActionSheet.bind(null, true)}
            >
              <IonIcon slot="icon-only" icon={filterOutline}></IonIcon>
              <IonActionSheet
                isOpen={showSortPriceActionSheet}
                onDidDismiss={() => setShowSortPriceActionSheet(false)}
                buttons={[
                  {
                    text: "Price: low to hight",
                    handler: () => {
                      setSortOption(SortOption.priceLow);
                    },
                  },
                  {
                    text: "Price: hight to low",
                    handler: () => {
                      setSortOption(SortOption.priceHigh);
                    },
                  },
                  {
                    text: "Cancel",
                    role: "cancel",
                  },
                ]}
              ></IonActionSheet>
            </IonButton>

            <IonButton
              fill="clear"
              color="dark"
              onClick={handleShowFilterModal}
            >
              <IonIcon slot="icon-only" icon={optionsOutline}></IonIcon>
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonFooter>
    </IonPage>
  );
};

export default Products;
