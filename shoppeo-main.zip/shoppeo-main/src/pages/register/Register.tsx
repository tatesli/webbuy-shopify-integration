import React from "react";
import { useForm } from "react-hook-form";
import { useMutation } from "@apollo/client";
import {
  IonApp,
  IonBackButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonLoading,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import Input from "components/input/Input";
import Button from "components/button/Button";
import "./Register.css";
import { customerCreate } from "services/auth";

const Register: React.FC = () => {
  const [createCustomer, { loading, error, data }] =
    useMutation(customerCreate);
  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    setValue,
  } = useForm<{
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    password: string;
  }>({ mode: "all" });

  const onChange = (e: any, name: string) => {
    setValue(
      name as "firstName" | "lastName" | "email" | "phone" | "password",
      e.target.value
    );
  };
  const firstName = watch("firstName");
  const lastName = watch("lastName");
  const email = watch("email");
  const phone = watch("phone");
  const password = watch("password");
  const onSubmit = handleSubmit(async (data) => {
    try {
      const result = await createCustomer({
        variables: { customer: { ...data } },
      });
      console.log(result);
    } catch (error) {
      console.log(error);
    }
  });

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton></IonBackButton>
          </IonButtons>
          <IonTitle>Register</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonLoading isOpen={loading} duration={0}></IonLoading>
        {!loading && (
          <div className="register__wrapper">
            {/* Input for First Name */}
            <div>
              <Input
                label="First Name"
                placeholder="Enter First Name"
                name="firstName"
                type="text"
                value={firstName}
                onChange={onChange}
                error={errors?.firstName?.message}
                ref={
                  register("firstName", {
                    minLength: {
                      value: 3,
                      message: "First Name must be at least 3 characters.",
                    },
                    maxLength: {
                      value: 20,
                      message:
                        "First Name must be less than or equal to 20 characters.",
                    },
                  }) as any
                }
              />
            </div>
            {/* Input for Last Name */}
            <div>
              <Input
                label="Last Name"
                placeholder="Enter Last Name"
                name="lastName"
                type="text"
                value={lastName}
                onChange={onChange}
                error={errors?.lastName?.message}
                ref={
                  register("lastName", {
                    minLength: {
                      value: 3,
                      message: "Last Name must be at least 3 characters.",
                    },
                    maxLength: {
                      value: 20,
                      message:
                        "Last Name must be less than or equal to 20 characters.",
                    },
                  }) as any
                }
              />
            </div>
            {/* Input for Email */}
            <div>
              <Input
                label="Email"
                placeholder="Enter Email"
                name="email"
                type="text"
                value={email}
                onChange={onChange}
                error={errors?.email?.message}
                ref={
                  register("email", {
                    pattern: {
                      value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                      message: "Email is not valid",
                    },
                    required: { value: true, message: "Email is required" },
                  }) as any
                }
              />
            </div>
            {/* Input for Phone */}
            <div>
              <Input
                label="Phone"
                placeholder="+48"
                name="phone"
                type="text"
                value={phone}
                onChange={onChange}
                error={errors?.phone?.message}
                ref={register("phone") as any}
              />
            </div>
            {/* Input for Password */}
            <div>
              <Input
                label="Password"
                placeholder="Enter password"
                name="password"
                type="password"
                value={password}
                onChange={onChange}
                error={errors?.password?.message}
                ref={
                  register("password", {
                    required: { value: true, message: "Password is required" },
                  }) as any
                }
              />
            </div>
            {/* Register button */}
            <div>
              <Button onClick={onSubmit} label="Register" />
            </div>
          </div>
        )}
      </IonContent>
    </IonPage>
  );
};

export default Register;
