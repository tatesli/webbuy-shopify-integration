import {
  IonBackButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import React from "react";
import "./ContactUs.css";

const ContactUs: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton></IonBackButton>
          </IonButtons>
          <IonTitle>Privacy police</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <div className="contact__content">
          If you have any questions, comments, or concerns, please don't
          hesitate to contact us. You can reach us by email at
          info@yourstore.com, or by phone at +1-123-456-7890. Our customer
          support team is available Monday through Friday from 9:00am to 5:00pm
          EST.
          <br />
          Alternatively, you can fill out the contact form on our website and
          we'll get back to you as soon as possible. Thank you for shopping with
          us!
        </div>
      </IonContent>
    </IonPage>
  );
};

export default ContactUs;
