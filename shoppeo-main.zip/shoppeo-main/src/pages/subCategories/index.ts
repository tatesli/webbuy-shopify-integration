import SubCategories from "./SubCategories";

export default SubCategories;
