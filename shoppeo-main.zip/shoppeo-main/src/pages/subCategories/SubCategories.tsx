import React from "react";
import { RouteComponentProps } from "react-router-dom";
import { useHistory, useParams } from "react-router";
import {
  IonApp,
  IonBackButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonList,
  IonLoading,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";

import "./SubCategories.css";
import { categoriesByGender } from "../../feature/categories/products";
import useCategoriesQuery, { ProductType } from "hooks/useCategoriesQuery";
import { useDispatch, useSelector } from "react-redux";
import { selectCollection, setProductsType } from "store/products";

interface MatchParams {
  genderId: string;
}

interface SubCategoriesProps extends RouteComponentProps<MatchParams> {}

const SubCategories: React.FC<SubCategoriesProps> = ({ match }) => {
  const history = useHistory();
  const collection = useSelector(selectCollection);
  const dispatch = useDispatch();
  const { genderId } = match.params;
  const { loading, data, error } = useCategoriesQuery({ id: collection?.id });

  const handleProduct = (type: ProductType) => {
    dispatch(setProductsType(type));
    history.push(`/categories/${genderId}/${type.productType}`);
  };
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton defaultHref="/categories"></IonBackButton>
          </IonButtons>
          <IonTitle>Categories</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <IonLoading isOpen={loading} duration={0}></IonLoading>
        {data && !loading && !error && (
          <div className="sub-categories_list">
            {data.map((item) => (
              <div
                className="sub-categories_list-item"
                key={item.id}
                onClick={() => handleProduct(item)}
              >
                <div>
                  <div className="sub-categories_img-wrap">
                    <img src={item.image} alt={item.productType} />
                  </div>
                  <div className="sub-categories_title">{item.productType}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </IonContent>
    </IonPage>
  );
};

export default SubCategories;
