import {
  IonBackButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import React from "react";
import "./PrivacyPolice.css";

const PrivacyPolice: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton></IonBackButton>
          </IonButtons>
          <IonTitle>Privacy police</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <div className="privacy__content">
          Privacy Policy for Shoppe corp.
          <br />
          At Shoppe corp., we are committed to protecting the privacy of our
          users. This Privacy Policy outlines the types of information we
          collect from you when you use our Volodymyr Khvas mobile application
          (the “App”), how we use that information, and the steps we take to
          protect your information.
          <br />
          Information We Collect
          <br />
          We collect information about you when you use our App, including but
          not limited to: Your name and contact information
          (volodymyr.khvas@gmail.com) if you choose to create an account
          Information about your device, such as device type, operating system,
          and unique device identifier Your IP address and location information
          Usage data, such as the features of the App you use and the actions
          you take within the App Any other information you choose to provide to
          us through the App
          <br />
          How We Use Your Information
          <br />
          We may use the information we collect about you for the following
          purposes: To provide and maintain our App To personalize your
          experience and provide customized content and features To analyze
          usage of the App and improve our services To communicate with you
          about our services and respond to your inquiries To detect, prevent,
          and address technical issues and security threats
          <br />
          Third-Party Services
          <br />
          We may use third-party services, such as analytics tools and
          advertising networks, to help us operate our App. These third-party
          services may collect information about you when you use our App and
          may share that information with us. We are not responsible for the
          privacy practices of these third-party services, and we encourage you
          to review their privacy policies.
          <br />
          Data Retention
          <br />
          We will retain your information for as long as necessary to provide
          our services and as required by applicable law. If you would like us
          to delete your information, please contact us at shoppeo@shoppeo.com.
          Security We take reasonable measures to protect the information we
          collect from you against unauthorized access, disclosure, alteration,
          or destruction. However, no method of transmission over the Internet
          or method of electronic storage is 100% secure, and we cannot
          guarantee the absolute security of your information.
          <br />
          Changes to this Privacy Policy
          <br />
          We reserve the right to modify this Privacy Policy at any time. We
          will notify you of any changes by posting the updated Privacy Policy
          on our website or through the App. Your continued use of the App
          following any changes to this Privacy Policy constitutes your
          acceptance of those changes.
          <br />
          Contact Us
          <br />
          If you have any questions about this Privacy Policy, please contact us
          at shoppeo@shoppeo.com.
        </div>
      </IonContent>
    </IonPage>
  );
};

export default PrivacyPolice;
