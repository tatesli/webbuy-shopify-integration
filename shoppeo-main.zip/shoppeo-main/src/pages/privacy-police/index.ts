import PrivacyPolice from "./PrivacyPolice";

export default PrivacyPolice;
