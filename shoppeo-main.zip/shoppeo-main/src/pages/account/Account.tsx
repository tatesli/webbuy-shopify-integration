import React from "react";
import { useHistory } from "react-router";
import {
  IonContent,
  IonHeader,
  IonItem,
  IonLabel,
  IonList,
  IonListHeader,
  IonPage,
} from "@ionic/react";

import { TOKEN_KEY, getLocalStorage } from "utils/helper";
import useCustomerQuery from "hooks/useCustomerQuery";
import "./Account.css";
import Button from "components/button/Button";
import { useDispatch, useSelector } from "react-redux";
import { logout, selectIsAuthenticated } from "store/auth";

const Account: React.FC = () => {
  const history = useHistory();
  const isAuthenticated = useSelector(selectIsAuthenticated);
  const dispatch = useDispatch();
  const token = getLocalStorage(TOKEN_KEY);
  const { data } = useCustomerQuery({ token });
  const handleOrders = () => {
    history.push("/account/orders");
  };
  const handlePrivatePolice = () => {
    history.push("/account/privacy-police");
  };
  const handleContactUs = () => {
    history.push("/account/contact-us");
  };
  const handleAbout = () => {
    history.push("/account/about");
  };
  const handleLogout = () => {
    // @ts-ignore
    dispatch(logout());
  };
  return (
    <IonPage>
      <IonHeader>
        <div className="account__header">
          <div>{data?.displayName}</div>
          <div className="account__header-email">{data?.email}</div>
        </div>
      </IonHeader>
      <IonContent fullscreen>
        <div className="account__content">
          <IonList>
            <IonListHeader className="account__content-header">
              application
            </IonListHeader>
            <IonItem onClick={handleOrders}>
              <IonLabel>Orders</IonLabel>
            </IonItem>
            <IonItem>
              <IonLabel>Rate our app</IonLabel>
            </IonItem>
            <IonItem onClick={handleContactUs}>
              <IonLabel>Contact us</IonLabel>
            </IonItem>
            <IonItem onClick={handlePrivatePolice}>
              <IonLabel>Privacy police</IonLabel>
            </IonItem>
            <IonItem onClick={handleAbout}>
              <IonLabel>About the app</IonLabel>
            </IonItem>
          </IonList>
          {isAuthenticated && (
            <div>
              <Button label="Logout" onClick={handleLogout} fill />
            </div>
          )}
        </div>
      </IonContent>
    </IonPage>
  );
};

export default Account;
