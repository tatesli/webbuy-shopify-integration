import React from "react";
import {
  IonBackButton,
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonLoading,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import useCartQuery from "hooks/useCartQuery";
import { useSelector } from "react-redux";
import { selectCartId } from "store/cart";
import { CartItem } from "feature/cart";
import Button from "components/button/Button";

import "./Cart.css";
import { useHistory } from "react-router";

const Cart: React.FC = () => {
  const history = useHistory();
  const cartId = useSelector(selectCartId);
  const { data, loading, refetch } = useCartQuery({ id: cartId! });
  const handleCheckout = () => {
    history.push("/cart/checkout");
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton></IonBackButton>
          </IonButtons>
          <IonTitle>Cart</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonLoading isOpen={loading} duration={0}></IonLoading>
        {!data ? (
          <div className="cart__page">
            <div className="cart__page-text">Cart is empty</div>
          </div>
        ) : (
          <div className="cart__main">
            <div className="cart__main-content">
              {data.items.map((cartItem) => (
                <CartItem
                  key={cartItem.id}
                  product={cartItem}
                  onRefresh={refetch}
                />
              ))}
            </div>
            <div className="cart__main-amount">
              <IonList>
                <IonItem className="cart__main-amount-total">
                  <IonLabel>Total:</IonLabel>
                  <p>
                    {data.totalAmount} {data.currencyCode}
                  </p>
                </IonItem>
              </IonList>
              <div className="cart__main-btn">
                <Button label="Checkout" onClick={handleCheckout} />
              </div>
            </div>
          </div>
        )}
      </IonContent>
    </IonPage>
  );
};

export default Cart;
