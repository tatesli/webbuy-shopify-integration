import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import * as serviceWorkerRegistration from "./serviceWorkerRegistration";
import reportWebVitals from "./reportWebVitals";
import { Provider } from "react-redux";
import { store } from "./store";
import { ApolloClient, ApolloProvider, InMemoryCache } from "@apollo/client";
import { Router } from "react-router-dom";
import { createBrowserHistory } from "history";

const history = createBrowserHistory();

const client = new ApolloClient({
  uri: "https://test-store-test-app.myshopify.com/api/2023-04/graphql.json",
  cache: new InMemoryCache(),
  headers: {
    "X-Shopify-Storefront-Access-Token": "f6c67c49571d4fe0fb133e6df22302aa",
  },
});

const container = document.getElementById("root");
const root = createRoot(container!);

root.render(
  <React.StrictMode>
    <ApolloProvider client={client}>
      <Provider store={store}>
        <Router history={history}>
          <App />
        </Router>
      </Provider>
    </ApolloProvider>
  </React.StrictMode>
);

serviceWorkerRegistration.unregister();

reportWebVitals();
