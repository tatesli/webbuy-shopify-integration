import { gql } from "@apollo/client";

export const cartCreate = gql`
  mutation cartCreate($cart: CartInput) {
    cartCreate(input: $cart) {
      cart {
        id
      }
      userErrors {
        code
        field
        message
      }
    }
  }
`;

export const cartLineAdd = gql`
  mutation cartLinesAdd($id: ID!, $items: [CartLineInput!]!) {
    cartLinesAdd(cartId: $id, lines: $items) {
      cart {
        createdAt
        updatedAt
        id
      }
      userErrors {
        code
        field
        message
      }
    }
  }
`;

export const cartLinesUpdate = gql`
  mutation cartLinesUpdate($id: ID!, $items: [CartLineUpdateInput!]!) {
    cartLinesUpdate(cartId: $id, lines: $items) {
      cart {
        createdAt
        updatedAt
        id
      }
      userErrors {
        code
        field
        message
      }
    }
  }
`;

export const cartLinesRemove = gql`
  mutation cartLinesRemove($id: ID!, $itemId: [ID!]!) {
    cartLinesRemove(cartId: $id, lineIds: $itemId) {
      cart {
        createdAt
        updatedAt
        id
      }
      userErrors {
        code
        field
        message
      }
    }
  }
`;

export const getCart = gql`
  query cart($id: ID!) {
    cart(id: $id) {
      createdAt
      updatedAt
      id
      cost {
        totalAmount {
          amount
          currencyCode
        }
      }
      totalQuantity
      lines(first: 100) {
        nodes {
          id
          merchandise {
            ... on ProductVariant {
              id
              title
              selectedOptions {
                name
                value
              }
              price {
                amount
                currencyCode
              }
              image {
                src
              }
              product {
                title
              }
            }
          }
          quantity
          cost {
            totalAmount {
              amount
              currencyCode
            }
          }
        }
      }
    }
  }
`;
