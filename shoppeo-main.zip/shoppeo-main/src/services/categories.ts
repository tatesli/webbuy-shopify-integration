import { gql } from "@apollo/client";

export const getCollections = gql`
  query {
    collections(first: 4) {
      edges {
        node {
          id
          title
          image {
            url
          }
        }
      }
    }
  }
`;

export const getCategories = gql`
  query collection($id: ID!) {
    collection(id: $id) {
      products(first: 100) {
        nodes {
          productType
          id
          images(first: 1) {
            nodes {
              src
            }
          }
        }
      }
    }
  }
`;
// products(first: 20, filters: { productType: $productType }) {
export const getProducts = gql`
  query products($collectionId: ID!) {
    collection(id: $collectionId) {
      title
      products(first: 20) {
        nodes {
          title
          handle
          description
          id
          productType
          images(first: 1) {
            edges {
              node {
                src
              }
            }
          }
          priceRange {
            minVariantPrice {
              amount
              currencyCode
            }
          }
          options {
            name
            values
          }
        }
      }
    }
  }
`;

export const getProduct = gql`
  query product($id: ID!) {
    product(id: $id) {
      id
      description
      productType
      title
      variants(first: 100) {
        nodes {
          id
          availableForSale
          image {
            src
          }
          priceV2 {
            amount
            currencyCode
          }
          selectedOptions {
            name
            value
          }
          title
        }
      }
      options(first: 10) {
        name
        values
      }
    }
  }
`;

export const getProductRecommendations = gql`
  query productRecommendations($id: ID!) {
    productRecommendations(productId: $id) {
      collections(first: 20) {
        nodes {
          title
          products(first: 20) {
            nodes {
              title
              handle
              description
              id
              productType
              images(first: 1) {
                edges {
                  node {
                    src
                  }
                }
              }
              priceRange {
                minVariantPrice {
                  amount
                  currencyCode
                }
              }
              options {
                name
                values
              }
            }
          }
        }
      }
    }
  }
`;

export const getMainProducts = gql`
  query products {
    products(first: 20) {
      nodes {
        title
        handle
        description
        id
        productType
        images(first: 1) {
          edges {
            node {
              src
            }
          }
        }
        priceRange {
          minVariantPrice {
            amount
            currencyCode
          }
        }
        options {
          name
          values
        }
      }
    }
  }
`;
