import { gql } from "@apollo/client";

export const customerCreate = gql`
  mutation customerCreate($customer: CustomerCreateInput!) {
    customerCreate(input: $customer) {
      customer {
        id
      }
      customerUserErrors {
        code
        field
        message
      }
    }
  }
`;

export const customerAccessTokenCreate = gql`
  mutation customerAccessTokenCreate(
    $customer: CustomerAccessTokenCreateInput!
  ) {
    customerAccessTokenCreate(input: $customer) {
      customerAccessToken {
        accessToken
      }
      customerUserErrors {
        code
        field
        message
      }
    }
  }
`;

export const customer = gql`
  query customer($token: String!) {
    customer(customerAccessToken: $token) {
      displayName
      email
    }
  }
`;

export const getOrders = gql`
  query customer($token: String!) {
    customer(customerAccessToken: $token) {
      orders(first: 100) {
        nodes {
          email
          id
          fulfillmentStatus
          financialStatus
          name
          orderNumber
          phone
          subtotalPrice {
            amount
            currencyCode
          }
          lineItems(first: 100) {
            nodes {
              currentQuantity
              quantity
              title
            }
          }
          statusUrl
        }
      }
    }
  }
`;
