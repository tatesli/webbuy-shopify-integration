import { gql } from "@apollo/client";

export const checkoutCreate = gql`
  mutation checkoutCreate($input: CheckoutCreateInput!) {
    checkoutCreate(input: $input) {
      queueToken
      checkout {
        availableShippingRates {
          ready
          shippingRates {
            handle
            price {
              amount
              currencyCode
            }
            title
          }
        }
        completedAt
        id
        createdAt
        lineItemsSubtotalPrice {
          amount
          currencyCode
        }
        totalPrice {
          amount
          currencyCode
        }
        totalTax {
          amount
          currencyCode
        }
        shippingAddress {
          city
          country
          address1
          address2
          firstName
          lastName
          phone
          zip
        }
        lineItems(first: 100) {
          nodes {
            id
            title
            quantity
            variant {
              image {
                url
              }
              title
              price {
                amount
                currencyCode
              }
            }
          }
        }
      }
      checkoutUserErrors {
        code
        field
        message
      }
    }
  }
`;
export const updateCheckout = gql`
  mutation updateCheckout($id: ID!) {
    checkoutShippingLineUpdate(
      checkoutId: $id
      shippingRateHandle: "free-shipping"
    ) {
      checkout {
        id
      }
    }
  }
`;
export const checkoutCompleteFree = gql`
  mutation checkoutCompleteFree($checkoutId: ID!) {
    checkoutCompleteFree(checkoutId: $checkoutId) {
      checkout {
        completedAt
        id
      }
      checkoutUserErrors {
        code
        field
        message
      }
    }
  }
`;

export const checkoutCompleteV2 = gql`
  mutation checkoutComplete(
    $checkoutId: ID!
    $payment: CreditCardPaymentInputV2!
  ) {
    checkoutCompleteWithCreditCardV2(
      checkoutId: $checkoutId
      payment: $payment
    ) {
      checkoutUserErrors {
        code
        field
        message
      }
    }
  }
`;
