import {
  IonButton,
  IonCheckbox,
  IonItem,
  IonLabel,
  IonModal,
  IonRange,
} from "@ionic/react";

import React, { useEffect, useState } from "react";

import { Colors, Product, ProductSize } from "../products";

import "./FilterModal.css";
import Button from "components/button/Button";
import classNames from "classnames";

const FilterModal: React.FC<{
  onClose: () => void;
  isOpen: boolean;
  products: Product[] | null;
}> = ({ onClose, isOpen, products }) => {
  let updateProduct = products?.map((item) => item.price);
  const minPrice = Math.min.apply(Math, updateProduct!);

  const maxPrice = Math.max.apply(Math, updateProduct!);

  const [rangePriceValue, setRangePriceValue] = useState<{
    lower: number;
    upper: number;
  }>({ lower: 0, upper: 1000 });

  const onIonRangChange = (e: any) => {
    setRangePriceValue(e.detail.value as any);
  };

  return (
    <IonModal isOpen={isOpen} class="filters-modal">
      <div className="filters-modal-btn">
        <Button label="Filters" onClick={onClose} />
      </div>
      <div className="filters-modal__range">
        <div className="filters-modal__title">By Price</div>
        <IonRange
          dualKnobs={true}
          step={1}
          min={minPrice}
          max={maxPrice}
          ticks={true}
          onIonChange={(e: any) => onIonRangChange(e)}
        >
          <IonLabel slot="start">{minPrice}</IonLabel>
          <IonLabel slot="end">{maxPrice}</IonLabel>
        </IonRange>
        <IonItem>
          <IonLabel>
            Value: lower: {rangePriceValue.lower} upper: {rangePriceValue.upper}
          </IonLabel>
        </IonItem>
      </div>
      <div>
        <div className="filters-modal__title">By Color</div>
        {Colors.map((item, idx) => (
          <IonItem key={idx}>
            <div className="filters-modal__labels">
              <IonLabel className="filters-modal__labels">{item.name}</IonLabel>
            </div>
            <IonCheckbox
              className="filters-modal__checkbox"
              slot="start"
            ></IonCheckbox>
          </IonItem>
        ))}
      </div>
      <div>
        <div className="filters-modal__title">By Size</div>
        {ProductSize.map((item, idx) => (
          <IonItem key={idx}>
            <IonLabel className="filters-modal__labels">{item}</IonLabel>
            <IonCheckbox
              className="filters-modal__checkbox"
              slot="start"
              onIonChange={() => {}}
            ></IonCheckbox>
          </IonItem>
        ))}
      </div>
      <div
        className={classNames("filters-modal-btn", "filters-modal-bottom-btn")}
      >
        <Button label="Show things" onClick={onClose} />
      </div>
    </IonModal>
  );
};

export default FilterModal;
