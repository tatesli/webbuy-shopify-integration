import React from "react";
import { IonIcon } from "@ionic/react";
import { star, starOutline } from "ionicons/icons";
import "./RatingStar.css";

const Star: React.FC<{ fill: boolean }> = ({ fill }) => {
  return (
    <IonIcon
      icon={fill ? star : starOutline}
      style={{ color: "#E9A05D" }}
    ></IonIcon>
  );
};

const RatingStar: React.FC<{
  value: number;
  onSaveRating: (value: number) => void;
  readonly: boolean;
}> = ({ value, onSaveRating, readonly }) => {
  return (
    <div className="rating-star">
      {[1, 2, 3, 4, 5].map((item, idx) => (
        <div
          key={idx}
          onClick={readonly ? undefined : onSaveRating.bind(null, item)}
        >
          <Star fill={value >= item} />
        </div>
      ))}
    </div>
  );
};

export default RatingStar;
