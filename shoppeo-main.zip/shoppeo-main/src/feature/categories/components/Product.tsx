import React, { useState } from "react";
import { IonIcon, IonLabel } from "@ionic/react";
import { heart, heartOutline } from "ionicons/icons";

import { ProductCardType } from "pages/products/Products";
import "./Product.css";
import { Product } from "../../../hooks/useProductsQuery";
import { colors } from "utils/colors";

const ProductCard: React.FC<{
  product: Product;
  onClick: (e: React.MouseEvent) => void;
  type: ProductCardType;
}> = ({ product, onClick, type }) => {
  const [favorite, setFavorite] = useState(false);

  const onLikeBtnClick = (e: any) => {
    e.stopPropagation();
    setFavorite(favorite ? false : true);
  };
  const productColors = product.options.find(
    (option) => option.name === "Color"
  )?.values;

  return (
    <div
      className={`product ${
        type === ProductCardType.grid ? "product--grid" : "product--list"
      }`}
    >
      <div className="product__top" onClick={onClick}>
        <div className="product__top-img">
          <img src={product.image} alt={product.id} />
          <div className="product__top-favorite">
            <IonIcon
              className="product__top-block-favorite-heart"
              slot="icon-only"
              icon={favorite ? heart : heartOutline}
              style={{ color: "red" }}
              onClick={onLikeBtnClick}
            />
          </div>
        </div>
      </div>
      <div className="product__bottom">
        <IonLabel className="product__bottom-title">{product.title}</IonLabel>
        <div className="product__bottom-price">
          {product.price.amount}
          {product.price.currencyCode}
        </div>
        <div className="product__bottom-block">
          <div className="product__bottom-block-colors">
            {productColors?.map((item, idx) => (
              <button
                key={idx}
                className="product__bottom-left-colors-btn"
                style={{
                  background: colors[`${item.toLowerCase()}`] ?? "#fff",
                }}
              ></button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
