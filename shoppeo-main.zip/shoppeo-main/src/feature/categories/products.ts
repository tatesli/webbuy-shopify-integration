import { faker } from "@faker-js/faker";

import { nanoid } from "nanoid";

export type FilterState = {
  price?: { min?: number; max?: number };
  colors?: ProductColor["id"][];
  sizes?: SizeProduct[];
};
export type Product = {
  id: string;
  categoryId: string;
  title: string;
  image: string;
  price: number;
  rating: number;
  gender: string;

  inStock: ProductInStock[];
};

export type ProductCategory = {
  name: string;
  id: string;
  slug: string;
  image: string;
};
export type ProductCategoryByGender = {
  name: string;
  id: string;
  slug: string;
  image: string;
  subCategories: ProductCategory[];
};
export type ProductInStock = {
  color: ProductColor;
  sizes: ProductStockSizeCount[];
};
export type ProductStockSizeCount = {
  size: SizeProduct;
  count: number;
};

export enum SizeProduct {
  S = "S",
  M = "M",
  L = "L",
  XL = "XL",
  XXL = "XXL",
}
export const ProductSize: SizeProduct[] = [
  SizeProduct.S,
  SizeProduct.L,
  SizeProduct.M,
  SizeProduct.XL,
  SizeProduct.XXL,
];
export type ProductColor = {
  name: string;
  hex: string;
  id: number;
};
export const Colors: ProductColor[] = [
  { name: "Grey", hex: "#C4C4C4", id: 0 },
  { name: "Rose", hex: "#DDBABA", id: 1 },
  { name: "Blue", hex: "#809BCE", id: 2 },
];

export const categories: ProductCategory[] = [
  {
    name: "T-shirt",
    slug: "t-shirt",
    id: "1",
    image: `${faker.image.imageUrl(700, 830)}`,
  },
  {
    name: "Blouse",
    slug: "blouse",
    id: "2",
    image: `${faker.image.imageUrl(700, 830)}`,
  },
  {
    name: "Jackets",
    slug: "jackets",
    id: "3",
    image: `${faker.image.imageUrl(700, 830)}`,
  },
  {
    name: "Jeans",
    slug: "jeans",
    id: "4",
    image: `${faker.image.imageUrl(700, 830)}`,
  },
  {
    name: "Shorts",
    slug: "shorts",
    id: "5",
    image: `${faker.image.imageUrl(700, 830)}`,
  },
];

const getCategoriesByIds = (arr: number[]) => {
  return arr.map((ind) => categories[ind]);
};
export const categoriesByGender: ProductCategoryByGender[] = [
  {
    name: "Men",
    slug: "Men",
    id: "1",
    image: `${faker.image.imageUrl(515, 590)}`,
    subCategories: getCategoriesByIds([0, 2, 3, 4]),
  },
  {
    name: "Women",
    slug: "women",
    id: "2",
    image: `${faker.image.imageUrl(515, 590)}`,
    subCategories: getCategoriesByIds([1, 2, 3]),
  },
  {
    name: "Kids",
    slug: "kids",
    id: "3",
    image: `${faker.image.imageUrl(515, 590)}`,
    subCategories: getCategoriesByIds([0, 2, 4]),
  },
  {
    name: "Unisex",
    slug: "unisex",
    id: "4",
    image: `${faker.image.imageUrl(515, 590)}`,
    subCategories: categories,
  },
];

export const fetchProducts = async (
  params: {
    categoryId?: string;
    page?: number;
    gender?: string;
    filter?: FilterState;
  } = {}
): Promise<Product[]> => {
  await new Promise((r) => {
    setTimeout(r, 1000);
  }).catch((e) => {
    throw new Error(`Not found:${e}`);
  });

  const products: Product[] = [];
  const productInStock: ProductInStock[] = [];

  for (
    let i = 0;
    i < (params.filter?.colors ? params.filter.colors.length : Colors.length);
    i++
  ) {
    let size: ProductStockSizeCount[] = [];
    for (
      let i = 0;
      i <
      (params.filter?.sizes
        ? params.filter?.sizes?.length
        : ProductSize.length);
      i++
    ) {
      size.push({
        size: params.filter?.sizes ? params.filter?.sizes[i] : ProductSize[i],
        count: faker.datatype.number({ min: 1, max: 5 }),
      });
    }

    productInStock.push({
      color: params.filter?.colors
        ? Colors[params.filter.colors[i]]
        : Colors[i],
      sizes: size,
    });
  }

  const count = 20;
  const page = params.page || 1;
  for (let i = count * (page - 1); i < count * page; i++) {
    products.push({
      id: nanoid(),
      categoryId: params.categoryId
        ? params.categoryId
        : categories[Math.floor(Math.random() * 5)].id,
      title: faker.lorem.words(3),
      image: `${faker.image.imageUrl(820, 855)}?sig=${i}`,
      price: params.filter?.price
        ? faker.datatype.number({
            min: params.filter.price.min,
            max: params.filter.price.max,
          })
        : faker.datatype.number(1000),
      rating: faker.datatype.number({ min: 1, max: 5 }),
      gender: params.gender
        ? params.gender
        : categoriesByGender[Math.floor(Math.random() * 4)].id,

      inStock: productInStock,
    });
  }

  return products;
};
