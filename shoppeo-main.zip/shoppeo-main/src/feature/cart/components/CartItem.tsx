import React from "react";
import { IonButton, IonIcon, IonInput } from "@ionic/react";
import { closeOutline, removeOutline, addOutline } from "ionicons/icons";

import "./CartItem.css";
import { CartItem as CartItemType } from "hooks/useCartQuery";
import { colors } from "utils/colors";
import { useMutation } from "@apollo/client";
import { cartLinesRemove, cartLinesUpdate } from "services/cart";
import { useSelector } from "react-redux";
import { selectCartId } from "store/cart";

const CartItem: React.FC<{
  product: CartItemType;
  onRefresh: () => void;
}> = ({ product, onRefresh }) => {
  const cartId = useSelector(selectCartId);
  const [updateCartItem] = useMutation(cartLinesUpdate);
  const [removeCartItem] = useMutation(cartLinesRemove);
  const handleDelete = async () => {
    await removeCartItem({
      variables: {
        id: cartId,
        itemId: [product.cartIdItem],
      },
    });
    onRefresh();
  };
  const handleAdd = async () => {
    await updateCartItem({
      variables: {
        id: cartId,
        items: [{ id: product.cartIdItem, quantity: product.quantity + 1 }],
      },
    });
    onRefresh();
  };
  const handleRemove = async () => {
    if (product.quantity === 1) {
      handleDelete();
    }
    await updateCartItem({
      variables: {
        id: cartId,
        items: [{ id: product.cartIdItem, quantity: product.quantity - 1 }],
      },
    });
    onRefresh();
  };

  return (
    <div key={product.cartIdItem} className="cart-item">
      <div className="cart-item__left">
        <img src={product.image} alt={product.title} />
      </div>
      <div className="cart-item__right">
        <div className="cart-item__right-description">
          <div className="cart-item__right-description-info">
            <div className="cart-item__top-info-title">{product.title}</div>
            <div className="cart-item__bottom-price-label">
              {product.totalAmount} {product.currencyCode}
            </div>
          </div>
          <IonButton
            className="cart-item__top-btn-delete"
            size="small"
            color="dark"
            fill="clear"
            onClick={handleDelete}
          >
            <IonIcon icon={closeOutline}></IonIcon>
          </IonButton>
        </div>
        <div className="cart-item__right-bottom">
          <div className="cart-item__right-bottom-description">
            <div className="cart-item__right-bottom-description-size">
              Size: <p> {product.size}</p>
            </div>
            <div className="cart-item__right-bottom-description-color">
              Color:
              {
                <div
                  className="cart-item__right-bottom-description-colors"
                  style={{
                    background: colors[`${product.color.toLowerCase()}`],
                  }}
                ></div>
              }
            </div>
          </div>
          <div className="cart-item__right-bottom-count">
            <div className="cart-item__right-bottom-count-decrement">
              <IonButton fill="clear" onClick={handleRemove}>
                <IonIcon slot="icon-only" icon={removeOutline} />
              </IonButton>
            </div>
            <div className="cart-item__right-bottom-count-label">
              {product.quantity}
            </div>

            <div className="cart-item__right-bottom-count-increment">
              <IonButton fill="clear" onClick={handleAdd}>
                <IonIcon slot="icon-only" icon={addOutline} />
              </IonButton>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartItem;
