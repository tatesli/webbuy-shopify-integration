import { Redirect, Route } from "react-router-dom";
import { useHistory } from "react-router-dom";
import {
  IonApp,
  IonBadge,
  IonIcon,
  IonLabel,
  IonRouterOutlet,
  IonTabBar,
  IonTabButton,
  IonTabs,
  setupIonicReact,
} from "@ionic/react";
import { IonReactRouter } from "@ionic/react-router";
import {
  appsOutline,
  cartOutline,
  homeOutline,
  personOutline,
  searchOutline,
} from "ionicons/icons";

import Login from "pages/login";
import Register from "pages/register";
import Home from "pages/home";
import Account from "pages/account";
import Categories from "pages/categories";
import SubCategories from "pages/subCategories";
import Products from "pages/products";
import ProductDetails from "pages/product-details";
import Cart from "pages/cart";
import PrivacyPolice from "pages/privacy-police";
import ContactUs from "pages/contact-us";
import About from "pages/about";
import Orders from "pages/orders/Orders";
import Checkout from "pages/checkout";
import Order from "pages/order";

/* Core CSS required for Ionic components to work properly */
import "@ionic/react/css/core.css";

/* Basic CSS for apps built with Ionic */
import "@ionic/react/css/normalize.css";
import "@ionic/react/css/structure.css";
import "@ionic/react/css/typography.css";

/* Optional CSS utils that can be commented out */
import "@ionic/react/css/padding.css";
import "@ionic/react/css/float-elements.css";
import "@ionic/react/css/text-alignment.css";
import "@ionic/react/css/text-transformation.css";
import "@ionic/react/css/flex-utils.css";
import "@ionic/react/css/display.css";

/* Theme variables */
import "./theme/variables.css";
import "./theme/global.css";

import { useSelector } from "react-redux";
import { selectIsAuthenticated } from "./store/auth";
import { useEffect } from "react";
import { selectCartId } from "store/cart";
import useCartQuery from "hooks/useCartQuery";

setupIonicReact();

const App: React.FC = () => {
  const isAuthenticated = useSelector(selectIsAuthenticated);
  const history = useHistory();
  const cartId = useSelector(selectCartId);
  const { totalQuantity } = useCartQuery({ id: cartId });
  useEffect(() => {
    if (isAuthenticated) {
      history.push("/home");
    } else {
      history.push("/login");
    }
  }, [isAuthenticated, history]);

  return (
    <IonApp>
      {isAuthenticated ? (
        <IonReactRouter>
          <IonTabs>
            <IonRouterOutlet>
              <Route exact path="/:tab(home)" component={Home} />
              <Route
                exact
                path="/:tab(home)/:productId"
                component={ProductDetails}
              />
              <Route exact path="/:tab(cart)" component={Cart} />
              <Route exact path="/:tab(cart)/checkout" component={Checkout} />
              <Route
                exact
                path="/:tab(cart)/checkout/order"
                component={Order}
              />
              <Route exact path="/:tab(categories)" component={Categories} />
              <Route
                exact
                path="/:tab(categories)/:genderId"
                component={SubCategories}
              />
              <Route
                path="/:tab(categories)/:genderId/:categoryId"
                exact
                component={Products}
              />
              <Route
                path="/:tab(categories)/:genderId/:categoryId/:productId"
                exact
                component={ProductDetails}
              />
              <Route exact path="/:tab(account)" component={Account} />
              <Route exact path="/:tab(account)/orders" component={Orders} />
              <Route
                exact
                path="/:tab(account)/privacy-police"
                component={PrivacyPolice}
              />
              <Route
                exact
                path="/:tab(account)/contact-us"
                component={ContactUs}
              />
              <Route exact path="/:tab(account)/about" component={About} />
              <Route exact path="/:tab(account)/orders" component={Orders} />
            </IonRouterOutlet>
            <IonTabBar slot="bottom">
              <IonTabButton tab="home" href="/home">
                <IonIcon aria-hidden="true" icon={homeOutline} />
                <IonLabel>Home</IonLabel>
              </IonTabButton>
              <IonTabButton tab="categories" href="/categories">
                <IonIcon aria-hidden="true" icon={appsOutline} />
                <IonLabel>Categories</IonLabel>
              </IonTabButton>
              <IonTabButton tab="cart" href="/cart">
                <IonIcon aria-hidden="true" icon={cartOutline} />
                {!!totalQuantity && (
                  <IonBadge color="dark" className="header__cart-btn-badge">
                    {totalQuantity}
                  </IonBadge>
                )}
                <IonLabel>Cart</IonLabel>
              </IonTabButton>
              <IonTabButton tab="account" href="/account">
                <IonIcon aria-hidden="true" icon={personOutline} />
                <IonLabel>Account</IonLabel>
              </IonTabButton>
            </IonTabBar>
          </IonTabs>
        </IonReactRouter>
      ) : (
        <IonReactRouter>
          <IonRouterOutlet>
            <Route exact path="/login" component={Login} />
            <Route exact path="/register" component={Register} />
            <Route exact path="/">
              <Redirect to="/login" />
            </Route>
          </IonRouterOutlet>
        </IonReactRouter>
      )}
    </IonApp>
  );
};

export default App;
