export const unpackRelay = (obj: any) => {
  return obj?.edges?.map((_obj: any) => {
    return { ..._obj.node };
  });
};

export const TOKEN_KEY = "ACCESS_TOKEN";

export const CART_ID_KEY = "CART_ID";

export const removeLocalStorage = (tokenKey: string) =>
  localStorage.removeItem(tokenKey);

export const setLocalStorage = (tokenKey: string, accessToken: string) => {
  if (!accessToken) {
    return null;
  }

  return localStorage.setItem(tokenKey, JSON.stringify(accessToken));
};

export const getLocalStorage = (tokenKey: string) => {
  const savedData = localStorage.getItem(tokenKey);
  if (!savedData) {
    return null;
  }
  try {
    return JSON.parse(savedData);
  } catch (error) {
    removeLocalStorage(tokenKey);
    return null;
  }
};
