export const colors: { [key: string]: string } = {
  white: "#e8e1ce",
  blue: "#0f25e4",
  orange: "#e0bb2e",
  yellow: "#fffc48",
  black: "#000",
  green: "#2fdf75",
  red: "#ff4961",
  grey: "#989aa2",
  biege: "#e8e1ce",
  white_blue: "#50c8ff",
};
