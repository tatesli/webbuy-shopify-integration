import { useQuery } from "@apollo/client";
import { SortOption } from "pages/products/Products";

import { getProducts } from "services/categories";

interface ResponseProduct {
  title: string;
  description: string;
  handle: string;
  id: string;
  productType: string;
  images: {
    edges: {
      node: {
        src: string;
      };
    }[];
  };
  priceRange: {
    minVariantPrice: {
      amount: string;
      currencyCode: string;
    };
  };
  options: {
    name: string;
    values: [string];
  }[];
}

export interface Product {
  title: string;
  description: string;
  handle: string;
  id: string;
  productType: string;
  image: string;
  price: {
    amount: string;
    currencyCode: string;
  };
  options: {
    name: string;
    values: [string];
  }[];
}

const useProductsQuery = ({
  id,
  type,
  sort,
}: {
  id: string;
  type: string;
  sort?: SortOption;
}) => {
  const { loading, error, data } = useQuery<{
    collection: {
      products: {
        nodes: ResponseProduct[];
      };
    };
  }>(getProducts, {
    variables: { collectionId: id, productType: type },
  });

  const getPreparedData = () => {
    const preparedData: Product[] | undefined = data?.collection.products.nodes
      .map(({ images, priceRange, ...restProp }) => ({
        ...restProp,
        image: images.edges[0].node.src,
        price: priceRange.minVariantPrice,
      }))
      .filter(({ productType }) => productType === type);

    if (sort && preparedData?.length) {
      switch (sort) {
        case SortOption.priceLow:
          return preparedData?.sort(
            (a: Product, b: Product) =>
              Number(a.price.amount) - Number(b.price.amount)
          );
        case SortOption.priceHigh:
          return preparedData?.sort(
            (a: Product, b: Product) =>
              Number(b.price.amount) - Number(a.price.amount)
          );
      }
    }
    return preparedData;
  };

  return { loading, error, data: getPreparedData() };
};

export default useProductsQuery;
