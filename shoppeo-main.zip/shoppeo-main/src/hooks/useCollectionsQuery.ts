import { useQuery } from "@apollo/client";

import { getCollections } from "services/categories";

export interface Collection {
  id: string;
  image: { url: string };
  title: string;
}

const useCollectionsQuery = () => {
  const { loading, error, data } = useQuery<{
    collections: { edges: { node: Collection }[] };
  }>(getCollections);

  const preparedData = data?.collections.edges?.map((obj) => ({ ...obj.node }));

  return { loading, error, data: preparedData };
};

export default useCollectionsQuery;
