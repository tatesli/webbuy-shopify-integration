import { useQuery } from "@apollo/client";
import { customer } from "services/auth";

export interface Customer {
  displayName: string;
  email: string;
}

const useCustomerQuery = ({ token }: { token: string }) => {
  const { loading, error, data } = useQuery<{ customer: Customer }>(customer, {
    variables: { token },
  });

  return { loading, error, data: data?.customer };
};

export default useCustomerQuery;
