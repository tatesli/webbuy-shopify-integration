import { useQuery } from "@apollo/client";

import { getCollections, getProduct } from "services/categories";

export interface ResponseProductVariant {
  id: string;
  title: string;
  availableForSale: boolean;
  selectedOptions: {
    name: string;
    value: string;
  }[];
  image: {
    src: string;
  };
  priceV2: {
    amount: string;
    currencyCode: string;
  };
}
export interface ProductVariant {
  id: string;
  title: string;
  availableForSale: boolean;
  image: string;
  price: { amount: string; currencyCode: string };
  selectedOptions: {
    name: string;
    value: string;
  }[];
}

export interface ResponseProduct {
  id: string;
  description: string;
  productType: string;
  title: string;
  variants: {
    nodes: ResponseProductVariant[];
  };
  options: {
    name: string;
    values: [string];
  }[];
}

export interface Product {
  id: string;
  description: string;
  productType: string;
  title: string;
  variants: ProductVariant[];
  options: {
    name: string;
    values: [string];
  }[];
}

const useProductQuery = ({ id }: { id: string }) => {
  const { loading, error, data } = useQuery<{ product: ResponseProduct }>(
    getProduct,
    { variables: { id } }
  );

  const getPreparedData = () => {
    if (!data) {
      return undefined;
    }
    const { variants, ...restProps } = data?.product;
    const preparedData: Product = {
      ...restProps,
      variants: variants.nodes.map(({ image, priceV2, ...rest }) => ({
        ...rest,
        image: image.src,
        price: priceV2,
      })),
    };

    return preparedData;
  };

  return { loading, error, data: getPreparedData() };
};

export default useProductQuery;
