import { useQuery } from "@apollo/client";
import { SortOption } from "pages/products/Products";

import { getProductRecommendations } from "services/categories";

interface ResponseProduct {
  title: string;
  description: string;
  handle: string;
  id: string;
  productType: string;
  images: {
    edges: {
      node: {
        src: string;
      };
    }[];
  };
  priceRange: {
    minVariantPrice: {
      amount: string;
      currencyCode: string;
    };
  };
  options: {
    name: string;
    values: [string];
  }[];
}

export interface Product {
  title: string;
  description: string;
  handle: string;
  id: string;
  productType: string;
  image: string;
  price: {
    amount: string;
    currencyCode: string;
  };
  options: {
    name: string;
    values: [string];
  }[];
}

const useProductRecommendationsQuery = ({ id }: { id: string }) => {
  const { loading, error, data } = useQuery<{
    productRecommendations: {
      collections: {
        nodes: { products: { nodes: ResponseProduct[] } }[];
      };
    }[];
  }>(getProductRecommendations, {
    variables: { id },
  });
  console.log(data);
  const getPreparedData = () => {
    // const preparedData: Product[] | undefined =
    //   data?.collection.products.nodes.map(
    //     ({ images, priceRange, ...restProp }) => ({
    //       ...restProp,
    //       image: images.edges[0].node.src,
    //       price: priceRange.minVariantPrice,
    //     })
    //   );
    const preparedData: Product[] | undefined =
      data?.productRecommendations[0].collections.nodes[0].products.nodes.map(
        ({ images, priceRange, ...restProp }) => ({
          ...restProp,
          image: images.edges[0].node.src,
          price: priceRange.minVariantPrice,
        })
      );

    return preparedData;
  };
  console.log(getPreparedData());
  return { loading, error, data: getPreparedData() };
};

export default useProductRecommendationsQuery;
