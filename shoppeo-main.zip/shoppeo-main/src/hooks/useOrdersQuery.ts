import { useQuery } from "@apollo/client";
import { getOrders } from "services/auth";

interface ResponseOrders {
  orders: {
    nodes: {
      id: string;
      name: string;
      email: string;
      phone: string | null;
      financialStatus: string;
      fulfillmentStatus: string;
      orderNumber: number;
      subtotalPrice: {
        amount: string;
        currencyCode: string;
      };
      lineItems: {
        nodes: { title: string; quantity: number; currentQuantity: number }[];
      };
      statusUrl: string;
    }[];
  };
}

export interface Order {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  financialStatus: string;
  fulfillmentStatus: string;
  orderNumber: number;
  currencyCode: string;
  amount: string;
  products: { title: string; quantity: number; currentQuantity: number }[];
  statusUrl: string;
}

const useOrdersQuery = ({ token }: { token: string }) => {
  const { loading, error, data } = useQuery<{ customer: ResponseOrders }>(
    getOrders,
    {
      variables: { token },
    }
  );
  const preparedData: Order[] | undefined = data?.customer.orders.nodes.map(
    ({ subtotalPrice, lineItems, ...restProps }) => ({
      ...restProps,
      products: lineItems.nodes.map((product) => product),
      amount: subtotalPrice.amount,
      currencyCode: subtotalPrice.currencyCode,
    })
  );

  return { loading, error, data: preparedData };
};

export default useOrdersQuery;
