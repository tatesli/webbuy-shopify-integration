import { useQuery } from "@apollo/client";

import { getCategories } from "services/categories";

export interface ResponseProductTypeTypes {
  id: string;
  images: { nodes: { src: string }[] };
  productType: string;
}

export interface ProductType {
  id: string;
  image: string;
  productType: string;
}

const useCategoriesQuery = ({ id }: any) => {
  const { loading, error, data } = useQuery<{
    collection: { products: { nodes: ResponseProductTypeTypes[] } };
  }>(getCategories, {
    variables: { id },
  });

  const preparedData: ProductType[] | undefined =
    data?.collection.products.nodes
      .map(({ images, ...obj }) => ({
        ...obj,
        image: images.nodes[0].src,
      }))
      .filter(
        (type, index, list) =>
          list.findIndex((p) => p.productType === type.productType) === index
      );

  console.log(preparedData);

  return { loading, error, data: preparedData };
};

export default useCategoriesQuery;
