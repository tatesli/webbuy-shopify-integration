import { useQuery } from "@apollo/client";
import { getCart } from "services/cart";

interface ResponseCart {
  createdAt: string;
  updatedAt: string;
  id: string;
  cost: {
    totalAmount: {
      amount: string;
      currencyCode: string;
    };
  };
  totalQuantity: number;
  lines: {
    nodes: {
      id: string;
      merchandise: {
        id: string;
        title: string;
        selectedOptions: {
          name: string;
          value: string;
        }[];
        price: {
          amount: string;
          currencyCode: string;
        };
        image: {
          src: string;
        };
        product: {
          title: string;
        };
      };
      quantity: number;
      cost: {
        totalAmount: {
          amount: string;
          currencyCode: string;
        };
      };
    }[];
  };
}

export interface CartItem {
  cartIdItem: string;
  id: string;
  title: string;
  productTitle: string;
  size: string;
  color: string;
  image: string;
  quantity: number;
  totalAmount: string;
  currencyCode: string;
}

export interface Cart {
  createdAt: string;
  updatedAt: string;
  id: string;
  totalAmount: string;
  currencyCode: string;
  totalQuantity: number;
  items: CartItem[];
}

const useCartQuery = ({ id }: { id: string }) => {
  const { loading, error, data, refetch } = useQuery<{ cart: ResponseCart }>(
    getCart,
    {
      variables: { id },
      fetchPolicy: "no-cache",
    }
  );

  const getPrepareData = (): Cart | undefined => {
    if (!data) {
      return;
    }
    const { lines, cost, ...restCartProps } = data.cart;
    const cartItems: CartItem[] = lines.nodes.map(
      ({ merchandise, cost, id, quantity }) => ({
        quantity,
        cartIdItem: id,
        id: merchandise.id,
        title: merchandise.title,
        productTitle: merchandise.product.title,
        image: merchandise.image.src,
        totalAmount: cost.totalAmount.amount,
        currencyCode: cost.totalAmount.currencyCode,
        color:
          merchandise.selectedOptions.find(({ name }) => name === "Color")
            ?.value ?? "",
        size:
          merchandise.selectedOptions.find(({ name }) => name === "Size")
            ?.value ?? "",
      })
    );

    return {
      ...restCartProps,
      items: cartItems,
      totalAmount: cost.totalAmount.amount,
      currencyCode: cost.totalAmount.currencyCode,
    };
  };

  return {
    loading,
    error,
    data: getPrepareData(),
    refetch,
    totalQuantity: getPrepareData()?.totalQuantity,
  };
};

export default useCartQuery;
