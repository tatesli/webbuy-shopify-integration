import { useQuery } from "@apollo/client";

import { getMainProducts } from "services/categories";

interface ResponseProduct {
  title: string;
  description: string;
  handle: string;
  id: string;
  productType: string;
  images: {
    edges: {
      node: {
        src: string;
      };
    }[];
  };
  priceRange: {
    minVariantPrice: {
      amount: string;
      currencyCode: string;
    };
  };
  options: {
    name: string;
    values: [string];
  }[];
}

export interface Product {
  title: string;
  description: string;
  handle: string;
  id: string;
  productType: string;
  image: string;
  price: {
    amount: string;
    currencyCode: string;
  };
  options: {
    name: string;
    values: [string];
  }[];
}

const useMainProductsQuery = () => {
  const { loading, error, data } = useQuery<{
    products: {
      nodes: ResponseProduct[];
    };
  }>(getMainProducts);

  const getPreparedData = () => {
    const preparedData: Product[] | undefined = data?.products.nodes.map(
      ({ images, priceRange, ...restProduct }) => ({
        ...restProduct,
        image: images.edges[0].node.src,
        price: {
          amount: priceRange.minVariantPrice.amount,
          currencyCode: priceRange.minVariantPrice.currencyCode,
        },
      })
    );

    return preparedData;
  };

  return { loading, error, data: getPreparedData() };
};

export default useMainProductsQuery;
