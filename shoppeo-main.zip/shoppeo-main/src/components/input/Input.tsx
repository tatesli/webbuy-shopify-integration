import { IonInput, IonLabel } from "@ionic/react";
import React from "react";
import "./input.css";
import classNames from "classnames";

const Input: React.FC<{
  name: string;
  label: string;
  value?: string;
  placeholder: string;
  onChange: (e: any, name: string) => void;
  type: any;
  ref?: any;
  error?: string;
}> = ({ name, label, onChange, value, type, placeholder, ref, error }) => {
  return (
    <>
      <IonLabel position="stacked" className="label">
        {label}
      </IonLabel>
      <IonInput
        name={name}
        type={type}
        value={value}
        onIonChange={(e) => onChange(e, name)}
        placeholder={placeholder}
        className={"custom-input"}
        ref={ref}
      ></IonInput>
      {error && <p className="error-message">{error}</p>}
    </>
  );
};
export default Input;
