import { IonButton } from "@ionic/react";
import React from "react";
import classNames from "classnames";
import "./Button.css";

const Button: React.FC<{
  fill?: boolean;
  onClick?: () => void;
  label: string;
  disabled?: boolean;
  type?: any;
  children?: React.ReactNode;
}> = ({ label, onClick, fill, disabled, type, children }) => {
  return (
    <IonButton
      onClick={onClick}
      type={type}
      className={classNames("button", fill && "fill")}
      expand="block"
      fill={fill ? "outline" : "solid"}
      disabled={disabled}
    >
      {label}
      {children}
    </IonButton>
  );
};

export default Button;
