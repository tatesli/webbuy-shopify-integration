import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "./index";
import { Product } from "../feature/categories/products";
import { Collection } from "hooks/useCollectionsQuery";
import { ProductType } from "hooks/useCategoriesQuery";
import { Product as ProductDetailsType } from "hooks/useProductQuery";

type ProductsState = {
  productList: Product[] | null;
  productDetails: ProductDetailsType | null;
  collection: Collection | null;
  productsType: ProductType | null;
};

const initialState: ProductsState = {
  productList: null,
  productDetails: null,
  collection: null,
  productsType: null,
};

export const productsSlice = createSlice({
  name: "products",
  initialState,
  reducers: {
    setProducts(state, { payload: products }) {
      state.productList = products;
    },
    setProductDetails(state, { payload: product }) {
      state.productDetails = product;
    },
    setCollection(state, { payload: collection }) {
      state.collection = collection;
    },
    setProductsType(state, { payload: type }) {
      state.productsType = type;
    },
  },
});

export const selectProducts = ({ products: { productList } }: RootState) =>
  productList;

export const selectProduct = ({ products: { productDetails } }: RootState) =>
  productDetails;

export const selectCollection = ({ products: { collection } }: RootState) =>
  collection;

export const selectProductsType = ({ products: { productsType } }: RootState) =>
  productsType;

export const {
  setProducts,
  setProductDetails,
  setCollection,
  setProductsType,
} = productsSlice.actions;

export default productsSlice;
