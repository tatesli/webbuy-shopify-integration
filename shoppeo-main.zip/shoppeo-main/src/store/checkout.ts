import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "./index";

interface CheckoutState {
  checkout: any | null;
}

const initialState: CheckoutState = {
  checkout: null,
};

export const checkoutSlice = createSlice({
  name: "checkout",
  initialState,
  reducers: {
    setCheckout(state, { payload: checkout }) {
      state.checkout = checkout;
    },
  },
  extraReducers: {},
});

export const selectCheckout = ({ checkout: { checkout } }: RootState) => {
  const { lineItems, ...restProps } = checkout;

  return { ...restProps, items: [...lineItems.nodes] };
};

export const { setCheckout } = checkoutSlice.actions;

export default checkoutSlice;
