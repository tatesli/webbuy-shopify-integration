import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { RootState } from "./index";
import { CART_ID_KEY, getLocalStorage, setLocalStorage } from "utils/helper";

const getInitialState = () => {
  const cartId = getLocalStorage(CART_ID_KEY);
  return {
    cartId,
  };
};

export const setCartId = createAsyncThunk<void, { cartId: string }>(
  "cart/setCartId",
  async ({ cartId }) => {
    await setLocalStorage(CART_ID_KEY, cartId);
  }
);

export const cartSlice = createSlice({
  name: "cart",
  initialState: getInitialState(),
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(setCartId.fulfilled, () => getInitialState());
  },
});

export const selectCartId = ({ cart: { cartId } }: RootState) => cartId;

export default cartSlice;
