import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { RootState } from ".";
import {
  TOKEN_KEY,
  getLocalStorage,
  removeLocalStorage,
  setLocalStorage,
} from "utils/helper";

const getInitialState = () => {
  const authData = getLocalStorage(TOKEN_KEY);
  return {
    isAuthenticated: !!authData,
  };
};

export const login = createAsyncThunk<void, { token: string }>(
  "auth/login",
  async ({ token }) => {
    await setLocalStorage(TOKEN_KEY, token);
  }
);

export const logout = createAsyncThunk("auth/logout", async () =>
  removeLocalStorage(TOKEN_KEY)
);

export const authSlice = createSlice({
  name: "auth",
  initialState: getInitialState(),
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(login.fulfilled, (state) => {
      state.isAuthenticated = true;
    });
    builder.addCase(logout.fulfilled, () => getInitialState());
  },
});
export const selectIsAuthenticated = ({
  auth: { isAuthenticated },
}: RootState) => isAuthenticated;

export default authSlice;
