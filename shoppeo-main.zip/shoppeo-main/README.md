# shoppeo

```
node -v
v16.170
```
`npm i`

`ionic serve`
